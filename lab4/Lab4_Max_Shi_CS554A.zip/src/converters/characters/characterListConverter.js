import CharacterList from '../../entities/characters/characterList';

const characterListConverter = (characterList) => {
    return CharacterList(characterList);
};

export default characterListConverter;
