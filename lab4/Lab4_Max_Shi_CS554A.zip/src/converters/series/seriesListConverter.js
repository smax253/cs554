import SeriesList from '../../entities/series/seriesList';

const seriesListConverter = (seriesList) => {
    return SeriesList(seriesList);
};

export default seriesListConverter;
