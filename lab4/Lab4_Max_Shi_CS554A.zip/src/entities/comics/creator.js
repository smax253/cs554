const Creator = ({ name, role }) => ({
    getName: () => name,
    getRole: () => role,
});

export default Creator;
