import ComicList from '../../entities/comics/comicList';

const comicListConverter = (characterList) => {
    return ComicList(characterList);
};

export default comicListConverter;
